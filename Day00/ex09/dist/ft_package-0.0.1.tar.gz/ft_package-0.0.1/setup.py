from setuptools import setup, find_packages

setup(
    name="ft_package",
    version="0.0.1",
    description="A sample test package",
    long_description_content_type="text/plain",
    author="jhizdahr",
    author_email="jhizdahr@student.42yerevan.am",
    url="https://github.com/eagle/ft_package",
    license="MIT",
    packages=find_packages(),
    install_requires=[],
)