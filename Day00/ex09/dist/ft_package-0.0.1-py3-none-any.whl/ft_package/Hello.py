ft_list = ["Hello", "tata!"]
ft_tuple = ("Hello", "toto!")
ft_set = {"Hello", "tutu!"}
ft_dict = {"Hello" : "titi!"}

ft_list[1] = "World!"
ft_tuple = ("Hello", "Armenia!")
ft_set.remove("tutu!")
ft_set.add("Yerevan!")
ft_dict["Hello"] = "42Yerevan!"


print(ft_list)
print(ft_tuple)
print(ft_set)
print(ft_dict)